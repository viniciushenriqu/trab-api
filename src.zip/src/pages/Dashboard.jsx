import React from "react";
import "./Dashboard.css";

export const Dashboard = () => {
  return (
    <div className="dashboard-container">
      <div className="section-container">
        <h3>Armaduras</h3>
        <div className="scroll-box">
          <div className="item-card">
            <img src="/armadura1.png" alt="Armadura 1" />
            <h4>Armadura de Dragão</h4>
            <p>Proteção máxima com escamas de dragão.</p>
          </div>
          <div className="item-card">
            <img src="/armadura2.png" alt="Armadura 2" />
            <h4>Armadura Sagrada</h4>
            <p>Proteção divina contra maldições.</p>
          </div>
          <div className="item-card">
            <img src="/armadura3.png" alt="Armadura 3" />
            <h4>Armadura Sombria</h4>
            <p>Camuflagem nas sombras e defesa elevada.</p>
          </div>
          <div className="item-card">
            <img src="/armadura4.png" alt="Armadura 4" />
            <h4>Armadura de Cristal</h4>
            <p>Alta resistência e brilho encantador.</p>
          </div>
        </div>
      </div>

      <div className="section-container">
        <h3>Armas</h3>
        <div className="scroll-box">
          <div className="item-card">
            <img src="/espada1.png" alt="Espada 1" />
            <h4>Espada Lendária</h4>
            <p>Uma espada antiga com poder mágico.</p>
          </div>
          <div className="item-card">
            <img src="/arco1.png" alt="Arco 1" />
            <h4>Arco Élfico</h4>
            <p>Arco rápido e leve dos elfos.</p>
          </div>
          <div className="item-card">
            <img src="/espada2.png" alt="Espada 2" />
            <h4>Espada Flamejante</h4>
            <p>Incendeia os inimigos com cada golpe.</p>
          </div>
          <div className="item-card">
            <img src="/arco2.png" alt="Arco 2" />
            <h4>Arco de Caça</h4>
            <p>Ideal para combates à distância.</p>
          </div>
        </div>
      </div>
    </div>
  );
};
