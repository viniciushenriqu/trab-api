import React from "react";
import { Link } from "react-router-dom";
import "./Inventory.css";

export const Inventory = () => {
  const inventoryItems = [
    {
      id: 1,
      name: "Espada Lendária",
      description: "Uma espada antiga com poder mágico.",
      image: "/img/espada.png",
    },
    {
      id: 2,
      name: "Armadura de Dragão",
      description: "Proteção máxima com escamas de dragão.",
      image: "/img/armadura.png",
    },
    {
      id: 3,
      name: "Arco Élfico",
      description: "Arco rápido e leve dos elfos.",
      image: "/img/arco.png",
    },
  ];

  return (
    <div className="inventory-page">
      <div className="top-bar">
        <h1 className="site-title">Inventário</h1>
      </div>

      <div className="inventory-content">
        <h2>Seus Itens</h2>
        <div className="inventory-grid">
          {inventoryItems.map((item) => (
            <div className="item-card" key={item.id}>
              <img src={item.image} alt={item.name} />
              <h3>{item.name}</h3>
              <p>{item.description}</p>
              <Link to="/sell-item" state={{ item }} className="sell-button">
                Vender
              </Link>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
