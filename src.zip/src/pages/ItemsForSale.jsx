import React from "react";

export function ItemsForSale() {
  return <h1>Itens à venda</h1>;
}
