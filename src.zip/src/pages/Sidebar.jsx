import React from "react";
import { Link } from "react-router-dom";
import "./Sidebar.css";

export const Sidebar = ({ isOpen, toggleSidebar }) => {
  return (
    <div className={`sidebar ${isOpen ? "open" : ""}`}>
      <button className="close-btn" onClick={toggleSidebar}>
        ×
      </button>
      <ul>
        <li>
          <Link to="/inventory">Inventário</Link>
        </li>
        <li>
          <Link to="/for-sale">Itens à Venda</Link>
        </li>
        <li>
          <Link to="/">Dashboard</Link>
        </li>
      </ul>
    </div>
  );
};
