import React from "react";
import { Link } from "react-router-dom";
import "./Sidebar.css";

export const Sidebar = ({ isOpen }) => {
  return (
    <div className={`sidebar ${isOpen ? "open" : ""}`}>
      <Link to="/">Dashboard</Link>
      <Link to="/inventory">Inventário</Link>
      <Link to="/for-sale">Itens à Venda</Link>
    </div>
  );
};
