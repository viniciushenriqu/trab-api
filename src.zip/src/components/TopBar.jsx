import React from "react";
import "./TopBar.css";

export const TopBar = ({ toggleSidebar }) => {
  return (
    <div className="topbar">
      <button
        onClick={toggleSidebar}
        style={{
          background: "none",
          border: "none",
          color: "white",
          fontSize: "24px",
        }}
      >
        ☰
      </button>
      <h3 style={{ marginLeft: "1rem" }}>Sistema de Marketplace</h3>
    </div>
  );
};
